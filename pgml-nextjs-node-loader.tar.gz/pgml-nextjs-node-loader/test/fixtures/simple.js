import foo from './example/build/Release/hello.node';

const value = foo.hello();

export default value;
