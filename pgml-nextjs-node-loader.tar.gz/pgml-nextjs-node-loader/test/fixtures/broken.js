import foo from './broken.node';

export default foo;
